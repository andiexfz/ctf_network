Hi! Welcome,

so i created this website with:
- NextJs
- Tailwind
- Framer Motion
- DatoCMS
